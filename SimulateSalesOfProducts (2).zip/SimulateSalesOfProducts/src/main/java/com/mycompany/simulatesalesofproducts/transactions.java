
package com.mycompany.simulatesalesofproducts;

public class transactions {
    String buyer;
    int buyerDepotNumber;
    String seller;
    int sellerDepotNumber;
    int Quantity;
    int price;
    int totalprice;
    
    public transactions (String buyer_,int buyerDepotNumber_,String seller_,int sellerDepotNumber_,int Quantity_,int price_,int totalprice_){
     buyer=buyer_;
     buyerDepotNumber=buyerDepotNumber_;
     seller=seller_;
     sellerDepotNumber=sellerDepotNumber_;
     Quantity=Quantity_;
     price=price_;
     totalprice=totalprice_;
        
    }
    
    
}
